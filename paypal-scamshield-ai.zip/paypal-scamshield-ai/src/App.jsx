import React, { useState, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import HeroGreeting from './components/HeroGreeting';
import MetricCards from './components/MetricCards';
import RevenueChart from './components/RevenueChart';
import TransactionsTable from './components/TransactionsTable';
import NotificationsPanel from './components/NotificationsPanel';
import SyncStatusPanel from './components/SyncStatusPanel';
import ExplainRiskModal from './components/ExplainRiskModal';
import SimulatePaymentModal from './components/SimulatePaymentModal';
import LandingPageView from './components/LandingPageView';
import { INITIAL_METRICS, INITIAL_TRANSACTIONS } from './data/mockData';
import { CheckCircle2, Shield, AlertTriangle, ArrowRight, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [activeView, setActiveView] = useState('dashboard'); // 'dashboard' or 'landing'
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [metrics, setMetrics] = useState(INITIAL_METRICS);
  const [transactions, setTransactions] = useState(INITIAL_TRANSACTIONS);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Filtered transactions based on search query
  const filteredTransactions = useMemo(() => {
    if (!searchQuery.trim()) return transactions;
    const q = searchQuery.toLowerCase();
    return transactions.filter(t => 
      t.id.toLowerCase().includes(q) ||
      t.customer.toLowerCase().includes(q) ||
      t.email.toLowerCase().includes(q) ||
      t.total.toLowerCase().includes(q) ||
      t.riskLevel.toLowerCase().includes(q) ||
      (t.location && t.location.toLowerCase().includes(q))
    );
  }, [transactions, searchQuery]);

  // Action: Run Reconciliation
  const handleRunReconciliation = () => {
    showToast("ScamShield AI Reconciliation started... Auditing 1,420 transactions.");
    setTimeout(() => {
      showToast("Reconciliation complete! 1,420 transactions validated. 3 required step-up verification.");
    }, 1200);
  };

  // Action: Sync Now
  const handleSyncNow = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      showToast("PayPal webhook stream synced. 0 new unauthorized charges.");
    }, 1000);
  };

  // Action: Handle action taken in Explain modal
  const handleActionTaken = (txId, actionType) => {
    setTransactions(prev => prev.map(tx => {
      if (tx.id === txId) {
        if (actionType === 'REQUEST_VERIFICATION') {
          return {
            ...tx,
            status: 'Pending 2FA',
            aiVerdict: '2FA Challenge Sent',
            suggestedAction: 'REQUEST_VERIFICATION'
          };
        } else if (actionType === 'BLOCK_AND_REPORT') {
          return {
            ...tx,
            status: 'Declined',
            aiVerdict: 'Blocked & IP Frozen',
            riskBadgeColor: 'rose',
            suggestedAction: 'BLOCK_IMMEDIATELY'
          };
        } else {
          return {
            ...tx,
            status: 'Completed',
            aiVerdict: 'Settled Safely',
            riskBadgeColor: 'emerald',
            suggestedAction: 'PROCEED'
          };
        }
      }
      return tx;
    }));
    showToast(`Transaction ${txId} successfully updated with action: ${actionType.replace('_', ' ')}`);
  };

  // Action: Add simulated transaction
  const handleAddTransaction = (newTx) => {
    setTransactions(prev => [newTx, ...prev]);
    // update metric
    setMetrics(prev => prev.map(m => {
      if (m.id === 'transactions-flagged' && newTx.riskLevel === 'High') {
        return { ...m, value: `${parseInt(m.value) + 1}` };
      }
      return m;
    }));
    showToast(`New transaction ${newTx.id} analyzed and recorded into fraud telemetry ledger.`);
  };

  return (
    <div className="min-h-screen bg-[#121316] text-[#e2e8f0] flex font-sans selection:bg-blue-600 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#1e2029] border border-blue-500/40 text-white px-4 py-3 rounded-xl shadow-glow-blue flex items-center gap-3 animate-slideUp text-xs font-medium">
          <Sparkles size={16} className="text-blue-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* If Landing Page View is selected, show landing page with quick switch back */}
      {activeView === 'landing' ? (
        <div className="w-full">
          <Header 
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onRunReconciliation={handleRunReconciliation}
            onSyncNow={handleSyncNow}
            isSyncing={isSyncing}
            activeView={activeView}
            setActiveView={setActiveView}
            onOpenSimulator={() => setIsSimulatorOpen(true)}
          />
          <LandingPageView 
            onGoToDashboard={() => setActiveView('dashboard')}
            onOpenSimulator={() => setIsSimulatorOpen(true)}
          />
        </div>
      ) : (
        /* Exact Dashboard Experience matching the uploaded image */
        <>
          {/* Left Sidebar */}
          <Sidebar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isCollapsed={isSidebarCollapsed}
            setIsCollapsed={setIsSidebarCollapsed}
            brandTitle="BLUECONOMY"
          />

          {/* Main Content Area */}
          <div className="flex-1 min-w-0 flex flex-col min-h-screen">
            {/* Top Navigation Bar */}
            <Header
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onRunReconciliation={handleRunReconciliation}
              onSyncNow={handleSyncNow}
              isSyncing={isSyncing}
              activeView={activeView}
              setActiveView={setActiveView}
              onOpenSimulator={() => setIsSimulatorOpen(true)}
            />

            {/* Dashboard Body */}
            <main className="flex-1 p-6 max-w-[1600px] w-full mx-auto">
              {/* Feature Pill Callout */}
              <div className="mb-4 bg-gradient-to-r from-blue-900/30 via-slate-900/40 to-slate-900/20 border border-blue-500/20 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="font-semibold text-white">PayPal ScamShield AI:</span>
                  <span className="text-slate-300">
                    Active neural rules: Suspicious transaction detection • Pattern recognition • Risk score meter • Explainable reasoning • Verification router
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsSimulatorOpen(true)}
                    className="text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1"
                  >
                    <span>Simulate Fraud Attack</span>
                    <ArrowRight size={13} />
                  </button>
                </div>
              </div>

              {/* Hero Greeting: "Good morning, Aman." */}
              <HeroGreeting 
                userName="Aman" 
                activeAnomaliesCount={transactions.filter(t => t.riskLevel === 'High').length} 
              />

              {/* 4 Metric Cards Row: Net Revenue, Gross Revenue, Stripe Fees, Transactions */}
              <MetricCards metrics={metrics} />

              {/* 2-Column Main Workspace matching the uploaded screenshot */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Left / Center Main Column (approx 8.5 cols) */}
                <div className="lg:col-span-8 space-y-6">
                  {/* Revenue Trend Chart Card */}
                  <RevenueChart />

                  {/* Transactions Table Card */}
                  <TransactionsTable
                    transactions={filteredTransactions}
                    onSelectTransaction={(tx) => setSelectedTransaction(tx)}
                    onResolveTransaction={(txId) => {
                      const tx = transactions.find(t => t.id === txId);
                      setSelectedTransaction(tx);
                    }}
                  />
                </div>

                {/* Right Column (approx 3.5 cols) */}
                <div className="lg:col-span-4 space-y-6">
                  {/* Notifications Feed Card matching screenshot */}
                  <NotificationsPanel />

                  {/* Sync Status Card matching screenshot */}
                  <SyncStatusPanel
                    onFilterByStatus={(statusId) => {
                      showToast(`Filtered ledger by status: ${statusId.toUpperCase()}`);
                    }}
                  />
                </div>
              </div>
            </main>
          </div>
        </>
      )}

      {/* Explain Why A Payment Looks Suspicious Modal */}
      {selectedTransaction && (
        <ExplainRiskModal
          transaction={selectedTransaction}
          onClose={() => setSelectedTransaction(null)}
          onActionTaken={handleActionTaken}
        />
      )}

      {/* Interactive Fraud Simulator Modal */}
      {isSimulatorOpen && (
        <SimulatePaymentModal
          isOpen={isSimulatorOpen}
          onClose={() => setIsSimulatorOpen(false)}
          onAddTransaction={handleAddTransaction}
        />
      )}
    </div>
  );
}
