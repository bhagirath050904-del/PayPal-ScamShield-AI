export const INITIAL_METRICS = [
  {
    id: 'net-revenue',
    title: 'Net Revenue',
    subtitle: 'Week comparison',
    value: '$232,321',
    change: '↑',
    progress: 75,
    barColor: '#10b981', // green
    badgeText: '+14.2% vs last week',
    isPositive: true,
    aiInsight: 'Protected against 14 fraudulent chargebacks this week'
  },
  {
    id: 'gross-revenue',
    title: 'Gross Revenue',
    subtitle: 'Month comparison',
    value: '$324,349',
    change: '↑',
    progress: 62,
    barColor: '#38bdf8', // blue/cyan
    badgeText: '+8.6% vs last month',
    isPositive: true,
    aiInsight: '99.4% genuine clean payment rate recorded'
  },
  {
    id: 'stripe-fees',
    title: 'Stripe & PayPal Fees',
    subtitle: 'Week comparison',
    value: '$690.00',
    change: '↑',
    progress: 45,
    barColor: '#a855f7', // purple
    badgeText: '$3,180 disputed fees avoided by AI',
    isPositive: true,
    aiInsight: 'Saved $3,180 in non-refundable dispute arbitration fees'
  },
  {
    id: 'transactions-flagged',
    title: 'Flagged Transactions',
    subtitle: 'Week comparison',
    value: '23',
    change: '↑',
    progress: 82,
    barColor: '#f43f5e', // coral / red
    badgeText: 'Action needed on 4 high-risk items',
    isPositive: false,
    aiInsight: 'Unusual velocity pattern detected across 6 IPs in Lagos & Kyiv'
  }
];

export const REVENUE_TREND_DATA = {
  Day: [
    { label: '00:00', value: 8200 },
    { label: '03:00', value: 5400 },
    { label: '06:00', value: 11200 },
    { label: '09:00', value: 29400 },
    { label: '12:00', value: 48200, isHighlight: true, highlightTitle: 'Today 12:45', highlightValue: '$48,200', tag: 'High Velocity Blocked' },
    { label: '15:00', value: 36100 },
    { label: '18:00', value: 28500 },
    { label: '21:00', value: 19800 },
  ],
  Week: [
    { label: 'Mon', value: 18400 },
    { label: 'Tue', value: 31200 },
    { label: 'Wed', value: 24800 },
    { label: 'Thu', value: 48200, isHighlight: true, highlightTitle: 'Thu 16th', highlightValue: '$48,200', tag: 'Anomaly Flagged' },
    { label: 'Fri', value: 39500 },
    { label: 'Sat', value: 22100 },
    { label: 'Sun', value: 16800 },
  ],
  Month: [
    { label: 'Jan', value: 24000 },
    { label: 'Feb', value: 22000 },
    { label: 'Mar', value: 12000 },
    { label: 'Apr', value: 36000 },
    { label: 'Jun', value: 28000 },
    { label: 'Jul', value: 48200, isHighlight: true, highlightTitle: 'June 16', highlightValue: '$48,200', tag: 'Risk Shield Active' },
    { label: 'Aug', value: 31000 },
    { label: 'Sep', value: 26000 },
    { label: 'Oct', value: 33000 },
    { label: 'Nov', value: 24000 },
    { label: 'Dec', value: 38000 },
  ]
};

export const INITIAL_TRANSACTIONS = [
  {
    id: '#654321',
    customer: 'David K. Miller',
    email: 'david.m.9912@proton.me',
    date: '20 Mar 2025',
    timestamp: '14:28:10 UTC',
    status: 'Completed',
    statusColor: 'emerald', // emerald pill like screenshot
    total: '$19.99',
    amountNum: 19.99,
    currency: 'USD',
    paymentMethod: 'PayPal Balance',
    ipAddress: '197.210.226.54',
    location: 'Lagos, Nigeria (Billing: San Jose, CA)',
    riskLevel: 'Medium',
    riskScore: 68,
    riskBadgeColor: 'amber',
    aiVerdict: 'Request Verification',
    isSuspicious: true,
    reasons: [
      'Severe Geographic Mismatch: User IP resolved to Lagos, Nigeria while PayPal account billing registered to San Jose, California.',
      'Unusual Device Signature: Headless Chromium user-agent fingerprint detected, common in automated account takeover bots.',
      'Time-zone discrepancy: System time on client differs by +8 hours from expected billing region.'
    ],
    patterns: [
      'Cross-border credential testing attempt',
      'Recent password reset occurred 14 minutes prior to transaction'
    ],
    recommendation: 'Request Step-Up Verification (SMS OTP / Biometric 2FA). Do not auto-settle funds until identity confirmed.',
    suggestedAction: 'REQUEST_VERIFICATION'
  },
  {
    id: '#345678',
    customer: 'Sarah Jenkins',
    email: 'sjenkins@techcorp.io',
    date: '21 Mar 2025',
    timestamp: '11:05:42 UTC',
    status: 'Completed',
    statusColor: 'emerald',
    total: '$30.00',
    amountNum: 30.00,
    currency: 'USD',
    paymentMethod: 'PayPal linked Visa (...4821)',
    ipAddress: '172.56.21.89',
    location: 'Austin, TX, United States',
    riskLevel: 'Low',
    riskScore: 12,
    riskBadgeColor: 'emerald',
    aiVerdict: 'Proceed Safely',
    isSuspicious: false,
    reasons: [
      'Known Trusted Device: Same iPhone 15 Pro hardware UUID used for 18 consecutive legitimate transactions over 9 months.',
      'Geo-IP Match: IP coordinates match shipping and billing address within 4 miles.',
      'Behavioral Biometrics: Keystroke timing and mouse movement dynamics are fully consistent with genuine human interaction.'
    ],
    patterns: [
      'Consistent recurring monthly SaaS subscription pattern'
    ],
    recommendation: 'Proceed with instant automated clearance. No friction needed.',
    suggestedAction: 'PROCEED'
  },
  {
    id: '#901234',
    customer: 'Alexei Voronin (Alias)',
    email: 'temp_x992@guerrillamail.com',
    date: '17 Mar 2025',
    timestamp: '03:19:55 UTC',
    status: 'Completed',
    statusColor: 'emerald',
    total: '$8.75',
    amountNum: 8.75,
    currency: 'USD',
    paymentMethod: 'Stripe Guest Checkout',
    ipAddress: '185.220.101.4',
    location: 'Frankfurt, Germany (Tor Exit Node)',
    riskLevel: 'High',
    riskScore: 94,
    riskBadgeColor: 'rose',
    aiVerdict: 'Block / Request Strict KYC',
    isSuspicious: true,
    reasons: [
      'Tor Exit Node Detected: Connection routed through known anonymous routing relay with 99.8% malicious fraud probability.',
      'Disposable Email Provider: Domain guerrillamail.com is on the global fraudulent burner domain blocklist.',
      'Smurfing Micro-Charge Pattern: 7 rapid micro-transactions ($1.50 - $9.00) initiated across different stolen card numbers in under 90 seconds.'
    ],
    patterns: [
      'Card testing / Bin checking bot attack',
      'Velocity: 7 transactions/min with high velocity decline rate on preceding attempts'
    ],
    recommendation: 'Immediate Authorization Freeze. Reject payment, block IP subnet, and report stolen card numbers to issuer.',
    suggestedAction: 'BLOCK_IMMEDIATELY'
  },
  {
    id: '#782190',
    customer: 'Elena Rostova',
    email: 'elena.rostova@designhub.co',
    date: '22 Mar 2025',
    timestamp: '09:44:12 UTC',
    status: 'Completed',
    statusColor: 'emerald',
    total: '$1,450.00',
    amountNum: 1450.00,
    currency: 'USD',
    paymentMethod: 'PayPal Business Account',
    ipAddress: '104.28.212.19',
    location: 'London, United Kingdom',
    riskLevel: 'Medium',
    riskScore: 59,
    riskBadgeColor: 'amber',
    aiVerdict: 'Request Verification',
    isSuspicious: true,
    reasons: [
      'Unusual Order Magnitude: Single transaction amount is 12x higher than this customer\'s historical average ($120).',
      'New High-Value Category: First time purchasing digital cryptocurrency redemption vouchers from this account.'
    ],
    patterns: [
      'High-velocity basket size spike',
      'Immediate delivery non-refundable digital goods purchase'
    ],
    recommendation: 'Request Verification: Send prompt to customer\'s registered mobile device for biometric 2FA approval before digital key dispatch.',
    suggestedAction: 'REQUEST_VERIFICATION'
  },
  {
    id: '#410982',
    customer: 'Marcus Sterling',
    email: 'm.sterling@globex.org',
    date: '22 Mar 2025',
    timestamp: '08:12:30 UTC',
    status: 'Completed',
    statusColor: 'emerald',
    total: '$85.00',
    amountNum: 85.00,
    currency: 'USD',
    paymentMethod: 'PayPal Direct Debit',
    ipAddress: '66.249.92.10',
    location: 'Chicago, IL, United States',
    riskLevel: 'Low',
    riskScore: 8,
    riskBadgeColor: 'emerald',
    aiVerdict: 'Proceed Safely',
    isSuspicious: false,
    reasons: [
      'High Trust Score: Account age is 7 years with over 450 verified dispute-free PayPal transactions.',
      'Verified Address: PayPal Confirmed Shipping Address matches credit bureau records.',
      'Low Fraud Velocity: 0 failed checkout attempts in past 180 days.'
    ],
    patterns: [
      'Standard low-risk e-commerce transaction'
    ],
    recommendation: 'Proceed without interruption. Auto-approved by ScamShield AI Engine.',
    suggestedAction: 'PROCEED'
  }
];

export const INITIAL_NOTIFICATIONS = [
  {
    id: 'n1',
    type: 'success',
    iconType: 'check',
    iconBg: '#10b981', // green
    title: 'Reconciliation complete...',
    subtitle: 'All transactions are balanced and ready for review',
    time: '2m ago'
  },
  {
    id: 'n2',
    type: 'info',
    iconType: 'clock',
    iconBg: '#2a2d37', // dark gray
    title: 'Reconciliation in progre...',
    subtitle: 'Processing the latest transactions.',
    time: '8m ago'
  },
  {
    id: 'n3',
    type: 'warning',
    iconType: 'alert',
    iconBg: '#2a2d37',
    title: 'Review required',
    subtitle: "3 transactions couldn't be matched automatically",
    time: '18m ago'
  },
  {
    id: 'n4',
    type: 'sync',
    iconType: 'refresh',
    iconBg: '#2a2d37',
    title: 'New data synced',
    subtitle: '23 new transactions available for reconciliation',
    time: '34m ago'
  },
  {
    id: 'n5',
    type: 'file',
    iconType: 'file',
    iconBg: '#2563eb', // blue
    title: 'Some transactions wer...',
    subtitle: '23 new transactions available for reconciliation',
    time: '1h ago'
  },
  {
    id: 'n6',
    type: 'danger',
    iconType: 'danger',
    iconBg: '#ef4444', // red
    title: 'System check required',
    subtitle: "One background process didn't complete.",
    time: '2h ago'
  },
  {
    id: 'n7',
    type: 'user',
    iconType: 'user',
    iconBg: '#2a2d37',
    title: 'New sign-in detected...',
    subtitle: 'A new session was started.',
    time: '3h ago'
  }
];

export const SYNC_STATUS_ITEMS = [
  {
    id: 'pending',
    label: 'Pending',
    count: 10,
    dotColor: '#f59e0b', // amber
    barBg: 'rgba(245, 158, 11, 0.12)',
    textColor: '#f59e0b',
    border: 'border-amber-500/20'
  },
  {
    id: 'anomalies',
    label: 'Anomalies',
    count: 39,
    dotColor: '#ef4444', // red
    barBg: 'rgba(239, 68, 68, 0.12)',
    textColor: '#ef4444',
    border: 'border-red-500/20'
  },
  {
    id: 'duplicates',
    label: 'Duplicates',
    count: 22,
    dotColor: '#dc2626', // dark red
    barBg: 'rgba(220, 38, 38, 0.12)',
    textColor: '#f87171',
    border: 'border-rose-500/20'
  },
  {
    id: 'completed',
    label: 'Completed',
    count: 2,
    dotColor: '#3b82f6', // blue
    barBg: 'rgba(59, 130, 246, 0.15)',
    textColor: '#60a5fa',
    border: 'border-blue-500/20'
  }
];
