import React from 'react';
import { 
  Star, 
  Search, 
  ChevronRight, 
  Bell, 
  RefreshCw, 
  Sparkles, 
  SlidersHorizontal,
  ShieldCheck,
  Zap,
  Globe
} from 'lucide-react';

export default function Header({ 
  searchQuery, 
  setSearchQuery, 
  onRunReconciliation, 
  onSyncNow, 
  isSyncing,
  activeView,
  setActiveView,
  onOpenSimulator
}) {
  return (
    <header className="h-16 border-b border-[#23252d] bg-[#121316] px-6 flex items-center justify-between sticky top-0 z-20 backdrop-blur-md bg-opacity-95">
      {/* Left Breadcrumbs matching screenshot */}
      <div className="flex items-center gap-3">
        <button className="text-slate-500 hover:text-amber-400 transition-colors">
          <Star size={16} />
        </button>
        <div className="flex items-center gap-2 text-xs font-medium">
          <span className="text-slate-400 hover:text-slate-200 cursor-pointer">Dashboards</span>
          <span className="text-slate-600">/</span>
          <span className="text-slate-200 font-medium">Dashboard</span>
        </div>

        {/* View Switcher Pill */}
        <div className="ml-4 hidden lg:flex items-center bg-[#181920] border border-[#272935] p-0.5 rounded-lg text-[11px]">
          <button 
            onClick={() => setActiveView('dashboard')}
            className={`px-3 py-1 rounded-md font-medium transition-all ${
              activeView === 'dashboard' 
                ? 'bg-blue-600 text-white shadow-sm' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Dashboard
          </button>
          <button 
            onClick={() => setActiveView('landing')}
            className={`px-3 py-1 rounded-md font-medium transition-all flex items-center gap-1.5 ${
              activeView === 'landing' 
                ? 'bg-blue-600 text-white shadow-sm' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles size={12} className="text-sky-300" />
            Landing Page
          </button>
        </div>
      </div>

      {/* Center Search Input matching screenshot */}
      <div className="flex-1 max-w-md mx-6">
        <div className="relative">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search transactions, IP addresses, emails, risk scores..."
            className="w-full bg-[#171920] border border-[#262833] rounded-lg pl-9 pr-12 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/40 transition-all font-sans"
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] bg-[#22242e] border border-[#2c2f3d] px-1.5 py-0.5 rounded text-slate-400 font-mono">
            ⌘/
          </span>
        </div>
      </div>

      {/* Right Action Buttons matching screenshot */}
      <div className="flex items-center gap-3">
        {/* Sync Now button */}
        <button 
          onClick={onSyncNow}
          disabled={isSyncing}
          className="h-8 px-3 rounded-lg bg-[#181a21] hover:bg-[#22242e] border border-[#2a2d39] text-xs font-medium text-slate-200 flex items-center gap-1.5 transition-colors"
        >
          <RefreshCw size={13} className={`text-slate-400 ${isSyncing ? 'animate-spin text-blue-400' : ''}`} />
          <span>{isSyncing ? 'Syncing...' : 'Sync Now'}</span>
          <ChevronRight size={13} className="text-slate-500" />
        </button>

        {/* Run Reconciliation / AI Scan button */}
        <button 
          onClick={onRunReconciliation}
          className="h-8 px-4 rounded-lg bg-[#2563eb] hover:bg-blue-600 text-white text-xs font-medium shadow-sm transition-all hover:shadow-glow-blue flex items-center gap-1.5 active:scale-95"
        >
          <ShieldCheck size={14} />
          <span>Run Reconciliation</span>
        </button>

        {/* Interactive Payment Simulator trigger */}
        <button 
          onClick={onOpenSimulator}
          className="h-8 px-3 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-medium transition-all flex items-center gap-1.5"
          title="Simulate new transaction and test ScamShield AI risk detection"
        >
          <Zap size={13} className="text-emerald-400 animate-pulse" />
          <span className="hidden sm:inline">Test AI Detector</span>
        </button>

        {/* User Avatar & Notifications */}
        <div className="flex items-center gap-3 pl-2 border-l border-[#23252d]">
          {/* Avatar with image or stylized Aman */}
          <div className="relative group cursor-pointer">
            <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-600/60 bg-gradient-to-tr from-amber-600 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
              <img 
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80" 
                alt="Aman" 
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.parentElement.innerText = 'A';
                }}
              />
            </div>
            <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-emerald-500 border-2 border-[#121316]"></span>
          </div>

          {/* Bell Icon */}
          <button className="text-slate-400 hover:text-white transition-colors relative">
            <Bell size={16} />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full animate-ping"></span>
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full"></span>
          </button>
        </div>
      </div>
    </header>
  );
}
