import React, { useState } from 'react';
import { ChevronRight, Calendar, Sparkles, ShieldAlert } from 'lucide-react';
import { REVENUE_TREND_DATA } from '../data/mockData';

export default function RevenueChart() {
  const [activeTimeframe, setActiveTimeframe] = useState('Month');
  const [hoveredPoint, setHoveredPoint] = useState(null);

  const data = REVENUE_TREND_DATA[activeTimeframe] || REVENUE_TREND_DATA.Month;

  // Chart dimensions
  const width = 800;
  const height = 260;
  const paddingX = 40;
  const paddingBottom = 40;
  const paddingTop = 30;

  const chartWidth = width - paddingX * 2;
  const chartHeight = height - paddingTop - paddingBottom;

  const maxValue = Math.max(...data.map(d => d.value)) * 1.15;
  const minValue = 0;

  // Generate coordinates
  const points = data.map((d, index) => {
    const x = paddingX + (index / (data.length - 1)) * chartWidth;
    const y = paddingTop + chartHeight - ((d.value - minValue) / (maxValue - minValue)) * chartHeight;
    return { ...d, x, y, index };
  });

  // Generate smooth SVG curve path (catmull-rom or bezier)
  const generateSmoothPath = (pts) => {
    if (pts.length < 2) return '';
    let path = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i === 0 ? 0 : i - 1];
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const p3 = pts[i + 2 < pts.length ? i + 2 : i + 1];

      const cp1x = p1.x + (p2.x - p0.x) / 6;
      const cp1y = p1.y + (p2.y - p0.y) / 6;

      const cp2x = p2.x - (p3.x - p1.x) / 6;
      const cp2y = p2.y - (p3.y - p1.y) / 6;

      path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
    }
    return path;
  };

  const linePath = generateSmoothPath(points);
  const areaPath = `${linePath} L ${points[points.length - 1].x} ${paddingTop + chartHeight} L ${points[0].x} ${paddingTop + chartHeight} Z`;

  // Highlighted point (June 16 / $48,200 as seen in the screenshot)
  const defaultHighlight = points.find(p => p.isHighlight) || points[Math.floor(points.length / 2)];
  const activeTooltip = hoveredPoint || defaultHighlight;

  return (
    <div className="bg-[#18191e] border border-[#23252e] rounded-xl p-5 mb-6 relative overflow-hidden shadow-sm">
      {/* Chart Top Header matching screenshot */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-1.5 cursor-pointer group">
          <h2 className="text-sm font-semibold text-white tracking-wide group-hover:text-blue-400 transition-colors">
            Revenue Trend
          </h2>
          <ChevronRight size={16} className="text-slate-400 group-hover:text-blue-400 transition-colors" />
        </div>

        {/* Right filter controls: Day / Week / Month pill group + Calendar icon */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#15161b] p-0.5 rounded-lg border border-[#252733] text-xs">
            {['Day', 'Week', 'Month'].map((timeframe) => (
              <button
                key={timeframe}
                onClick={() => {
                  setActiveTimeframe(timeframe);
                  setHoveredPoint(null);
                }}
                className={`px-3 py-1 rounded-md font-medium text-xs transition-all ${
                  activeTimeframe === timeframe
                    ? 'bg-[#2563eb] text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {timeframe}
              </button>
            ))}
          </div>

          <button 
            className="w-8 h-8 rounded-lg bg-[#181a22] hover:bg-[#22242f] border border-[#262835] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            title="Custom Date Range Filter"
          >
            <Calendar size={14} />
          </button>
        </div>
      </div>

      {/* Interactive SVG Chart matching screenshot aesthetics */}
      <div className="relative w-full overflow-hidden">
        <svg 
          viewBox={`0 0 ${width} ${height}`} 
          className="w-full h-auto overflow-visible select-none"
        >
          <defs>
            {/* Gradient for area fill under the curve */}
            <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.22" />
              <stop offset="60%" stopColor="#2563eb" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#18191e" stopOpacity="0" />
            </linearGradient>

            {/* Glowing neon line filter */}
            <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="4" floodColor="#38bdf8" floodOpacity="0.6" />
            </filter>
          </defs>

          {/* Dotted Vertical Grid Lines matching screenshot */}
          {points.map((pt, i) => (
            <g key={i}>
              <line
                x1={pt.x}
                y1={paddingTop - 10}
                x2={pt.x}
                y2={paddingTop + chartHeight}
                stroke="#2a2c38"
                strokeWidth="1"
                strokeDasharray="4 4"
                opacity={activeTooltip?.label === pt.label ? 0.8 : 0.45}
              />
              {/* Bottom Label (Jan, Feb, Mar, etc.) */}
              <text
                x={pt.x}
                y={paddingTop + chartHeight + 22}
                textAnchor="middle"
                fill={activeTooltip?.label === pt.label ? '#ffffff' : '#64748b'}
                fontSize="11"
                fontWeight={activeTooltip?.label === pt.label ? '600' : '400'}
                fontFamily="Inter, sans-serif"
              >
                {pt.label}
              </text>
            </g>
          ))}

          {/* Area fill */}
          <path d={areaPath} fill="url(#areaGradient)" />

          {/* Curved Line */}
          <path
            d={linePath}
            fill="none"
            stroke="#38bdf8"
            strokeWidth="2.5"
            strokeLinecap="round"
            filter="url(#neonGlow)"
          />

          {/* Interactive touch/hover points */}
          {points.map((pt) => {
            const isSelected = activeTooltip?.label === pt.label;
            return (
              <g 
                key={pt.label} 
                className="cursor-pointer"
                onMouseEnter={() => setHoveredPoint(pt)}
              >
                {/* Hitbox */}
                <circle cx={pt.x} cy={pt.y} r="18" fill="transparent" />

                {isSelected && (
                  <>
                    {/* Glowing outer ring */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r="9"
                      fill="#38bdf8"
                      opacity="0.25"
                      className="animate-ping"
                    />
                    {/* Outer border ring */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r="6"
                      fill="#121316"
                      stroke="#38bdf8"
                      strokeWidth="2.5"
                    />
                    {/* Inner glowing core */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r="3"
                      fill="#ffffff"
                    />
                  </>
                )}
              </g>
            );
          })}
        </svg>

        {/* Floating Tooltip Card matching the screenshot (June 16 / $48,200) */}
        {activeTooltip && (
          <div
            className="absolute pointer-events-none transition-all duration-200 z-10"
            style={{
              left: `${(activeTooltip.x / width) * 100}%`,
              top: `${((activeTooltip.y + 15) / height) * 100}%`,
              transform: 'translate(-50%, 0)'
            }}
          >
            <div className="bg-gradient-to-b from-[#2563eb] to-[#1d4ed8] text-white px-4 py-2 rounded-xl shadow-glow-blue border border-blue-400/40 flex flex-col items-center justify-center min-w-[100px]">
              <span className="text-[10px] text-blue-100 font-medium tracking-tight">
                {activeTooltip.highlightTitle || activeTooltip.label}
              </span>
              <span className="text-sm font-bold tracking-tight text-white font-mono">
                {activeTooltip.highlightValue || `$${activeTooltip.value.toLocaleString()}`}
              </span>
              {activeTooltip.tag && (
                <span className="text-[9px] bg-blue-900/60 text-sky-200 px-1.5 py-0.2 rounded-full mt-0.5 border border-blue-300/30">
                  {activeTooltip.tag}
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
