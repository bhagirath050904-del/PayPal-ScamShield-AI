import React, { useState } from 'react';
import { 
  ChevronRight, 
  Pencil, 
  MoreHorizontal, 
  Trash2, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle,
  Eye,
  Filter,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

export default function TransactionsTable({ transactions, onSelectTransaction, onResolveTransaction }) {
  const [selectedIds, setSelectedIds] = useState([]);
  const [filterRisk, setFilterRisk] = useState('ALL');

  const handleToggleSelect = (id) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === transactions.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(transactions.map(t => t.id));
    }
  };

  const filteredTransactions = transactions.filter(t => {
    if (filterRisk === 'ALL') return true;
    if (filterRisk === 'HIGH') return t.riskLevel === 'High';
    if (filterRisk === 'MEDIUM') return t.riskLevel === 'Medium';
    if (filterRisk === 'LOW') return t.riskLevel === 'Low';
    return true;
  });

  return (
    <div className="bg-[#18191e] border border-[#23252e] rounded-xl p-5 overflow-hidden shadow-sm">
      {/* Header matching screenshot */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-1.5 cursor-pointer group">
          <h2 className="text-sm font-semibold text-white tracking-wide group-hover:text-blue-400 transition-colors">
            Transactions
          </h2>
          <ChevronRight size={16} className="text-slate-400 group-hover:text-blue-400 transition-colors" />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 bg-[#15161b] p-1 rounded-lg border border-[#232530] text-xs">
          {[
            { key: 'ALL', label: 'All' },
            { key: 'HIGH', label: 'High Risk', count: transactions.filter(t => t.riskLevel === 'High').length, color: 'text-rose-400' },
            { key: 'MEDIUM', label: 'Medium', count: transactions.filter(t => t.riskLevel === 'Medium').length, color: 'text-amber-400' },
            { key: 'LOW', label: 'Low Risk', count: transactions.filter(t => t.riskLevel === 'Low').length, color: 'text-emerald-400' },
          ].map(f => (
            <button
              key={f.key}
              onClick={() => setFilterRisk(f.key)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1 ${
                filterRisk === f.key 
                  ? 'bg-[#2563eb] text-white shadow-sm' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{f.label}</span>
              {f.count !== undefined && (
                <span className={`text-[10px] px-1 py-0.2 rounded-full ${
                  filterRisk === f.key ? 'bg-blue-800 text-white' : 'bg-[#22242e] text-slate-400'
                }`}>
                  {f.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Table matching screenshot structure */}
      <div className="overflow-x-auto -mx-5 px-5">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-[#23252f] text-slate-400 font-medium">
              <th className="py-3 px-3 w-10">
                <input
                  type="checkbox"
                  checked={selectedIds.length === transactions.length && transactions.length > 0}
                  onChange={handleSelectAll}
                  className="rounded border-[#343847] bg-[#1a1c24] text-blue-600 focus:ring-0 focus:ring-offset-0 cursor-pointer w-4 h-4"
                />
              </th>
              <th className="py-3 px-3 font-semibold text-slate-300">Number</th>
              <th className="py-3 px-3 font-semibold text-slate-300">Date</th>
              <th className="py-3 px-3 font-semibold text-slate-300">Status</th>
              <th className="py-3 px-3 font-semibold text-slate-300">AI Risk Score</th>
              <th className="py-3 px-3 font-semibold text-slate-300">Total</th>
              <th className="py-3 px-3 font-semibold text-slate-300">AI Recommendation</th>
              <th className="py-3 px-3 font-semibold text-slate-300 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f212a]">
            {filteredTransactions.map((tx) => {
              const isSelected = selectedIds.includes(tx.id);
              return (
                <tr 
                  key={tx.id}
                  className={`group hover:bg-[#1c1d25] transition-colors cursor-pointer ${
                    isSelected ? 'bg-[#1b1e2a]/50' : ''
                  }`}
                  onClick={() => onSelectTransaction(tx)}
                >
                  {/* Select Checkbox */}
                  <td className="py-3.5 px-3" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => handleToggleSelect(tx.id)}
                      className="rounded border-[#343847] bg-[#1a1c24] text-blue-600 focus:ring-0 focus:ring-offset-0 cursor-pointer w-4 h-4"
                    />
                  </td>

                  {/* Transaction Number / ID */}
                  <td className="py-3.5 px-3 font-mono font-medium text-slate-200">
                    <span className="group-hover:text-blue-400 transition-colors">
                      {tx.id}
                    </span>
                    <span className="block text-[10px] font-sans text-slate-400">
                      {tx.customer}
                    </span>
                  </td>

                  {/* Date */}
                  <td className="py-3.5 px-3 text-slate-300 whitespace-nowrap">
                    {tx.date}
                  </td>

                  {/* Status pill (Completed badge in light mint matching screenshot) */}
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-[11px] font-medium bg-[#10b981]/15 text-[#34d399] border border-[#10b981]/20">
                      {tx.status}
                    </span>
                  </td>

                  {/* AI Risk Score Pill */}
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <span 
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-semibold ${
                          tx.riskLevel === 'High'
                            ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                            : tx.riskLevel === 'Medium'
                            ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        }`}
                      >
                        {tx.riskLevel === 'High' && <AlertTriangle size={11} />}
                        {tx.riskLevel === 'Medium' && <ShieldAlert size={11} />}
                        {tx.riskLevel === 'Low' && <ShieldCheck size={11} />}
                        {tx.riskLevel} ({tx.riskScore}%)
                      </span>
                    </div>
                  </td>

                  {/* Total Amount */}
                  <td className="py-3.5 px-3 font-mono font-semibold text-slate-200 whitespace-nowrap">
                    {tx.total}
                  </td>

                  {/* AI Recommendation */}
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    <span className={`text-[11px] font-medium flex items-center gap-1.5 ${
                      tx.suggestedAction === 'BLOCK_IMMEDIATELY' 
                        ? 'text-rose-400' 
                        : tx.suggestedAction === 'REQUEST_VERIFICATION' 
                        ? 'text-amber-400' 
                        : 'text-emerald-400'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        tx.suggestedAction === 'BLOCK_IMMEDIATELY' 
                          ? 'bg-rose-400' 
                          : tx.suggestedAction === 'REQUEST_VERIFICATION' 
                          ? 'bg-amber-400' 
                          : 'bg-emerald-400'
                      }`}></span>
                      {tx.aiVerdict}
                    </span>
                  </td>

                  {/* Action Icons matching screenshot: edit, three dots, trash + Explain AI button */}
                  <td className="py-3.5 px-3 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-1.5 text-slate-400">
                      {/* Explain Why button */}
                      <button
                        onClick={() => onSelectTransaction(tx)}
                        className="px-2 py-1 rounded hover:bg-blue-600/20 text-slate-400 hover:text-blue-400 text-[11px] font-medium flex items-center gap-1 transition-colors"
                        title="View why this payment looks suspicious"
                      >
                        <Eye size={13} />
                        <span className="hidden xl:inline">Explain</span>
                      </button>

                      {/* Pencil edit */}
                      <button 
                        onClick={() => onResolveTransaction(tx.id)}
                        className="w-7 h-7 rounded hover:bg-[#232632] hover:text-slate-200 flex items-center justify-center transition-colors"
                        title="Edit / Resolve note"
                      >
                        <Pencil size={13} />
                      </button>

                      {/* Three dots */}
                      <button 
                        className="w-7 h-7 rounded hover:bg-[#232632] hover:text-slate-200 flex items-center justify-center transition-colors"
                        title="More options"
                      >
                        <MoreHorizontal size={14} />
                      </button>

                      {/* Trash */}
                      <button 
                        className="w-7 h-7 rounded hover:bg-rose-500/10 hover:text-rose-400 flex items-center justify-center transition-colors"
                        title="Dismiss / Archive"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
