import React from 'react';
import { ShieldCheck, Sparkles, AlertTriangle } from 'lucide-react';

export default function HeroGreeting({ userName = "Aman", activeAnomaliesCount = 3 }) {
  return (
    <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-1.5 font-sans">
          <span>Good morning,</span>
          <span className="font-extrabold text-white">
            {userName}
          </span>
          <span className="text-blue-500 font-extrabold">.</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 font-normal">
          Here's a quick snapshot of your Stripe & PayPal fraud detection activity
        </p>
      </div>

      {/* Real-time Status Badge */}
      <div className="flex items-center gap-2.5 bg-[#171920] border border-[#232530] px-3.5 py-2 rounded-xl">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-xs font-medium text-slate-300">ScamShield Neural Engine</span>
        </div>
        <div className="h-3.5 w-px bg-[#2d303d]"></div>
        <span className="text-[11px] text-emerald-400 font-mono font-medium">99.8% Precision</span>
      </div>
    </div>
  );
}
