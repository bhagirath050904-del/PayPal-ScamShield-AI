import React from 'react';
import { 
  LayoutDashboard, 
  ReceiptText, 
  RefreshCw, 
  AlertCircle, 
  CheckCircle2, 
  Settings, 
  ChevronRight, 
  ChevronLeft,
  Shield,
  Zap,
  Radio
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab, isCollapsed, setIsCollapsed, brandTitle = "BLUECONOMY" }) {
  return (
    <aside 
      className={`${
        isCollapsed ? 'w-20' : 'w-64'
      } transition-all duration-300 bg-[#121316] border-r border-[#23252d] flex flex-col justify-between select-none z-30 shrink-0 h-screen sticky top-0`}
    >
      <div className="flex flex-col">
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-5 border-b border-[#1f2128]">
          <div className="flex items-center space-x-3 overflow-hidden cursor-pointer" onClick={() => setActiveTab('Dashboard')}>
            {/* Custom stylized circular logo like Blueconomy screenshot */}
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 via-indigo-500 to-sky-400 flex items-center justify-center shrink-0 shadow-glow-blue">
              <span className="text-white font-extrabold text-sm tracking-tighter">e</span>
            </div>
            {!isCollapsed && (
              <div className="flex flex-col">
                <span className="font-bold tracking-wider text-sm text-white uppercase font-sans">
                  {brandTitle}
                </span>
                <span className="text-[10px] text-blue-400 font-mono tracking-tight flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  SCAMSHIELD AI
                </span>
              </div>
            )}
          </div>
          
          <button 
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="w-7 h-7 rounded-md bg-[#191b20] hover:bg-[#23252e] border border-[#272935] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>
        </div>

        {/* Navigation Content */}
        <div className="py-4 px-3 space-y-6 overflow-y-auto max-h-[calc(100vh-140px)]">
          {/* Favorites / Recently */}
          {!isCollapsed && (
            <div className="px-2">
              <div className="flex items-center justify-between text-[11px] font-medium text-slate-400 tracking-wide mb-2.5">
                <span>Favorites</span>
                <span className="text-slate-500 cursor-pointer hover:text-slate-300">Recently</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                <li 
                  onClick={() => setActiveTab('Transactions')}
                  className="flex items-center gap-2.5 px-2 py-1.5 rounded hover:bg-[#1a1c22] cursor-pointer transition-colors"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span>
                  <span>Transactions</span>
                </li>
                <li 
                  onClick={() => setActiveTab('Reconciliations')}
                  className="flex items-center gap-2.5 px-2 py-1.5 rounded hover:bg-[#1a1c22] cursor-pointer transition-colors"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span>
                  <span>Reconciliation</span>
                </li>
              </ul>
            </div>
          )}

          {/* Dashboards Section */}
          <div>
            {!isCollapsed && (
              <div className="px-2 mb-2 text-[11px] font-medium text-slate-400 tracking-wide">
                Dashboards
              </div>
            )}
            
            <nav className="space-y-1">
              {/* Dashboard Item (Active in Screenshot) */}
              <button
                onClick={() => setActiveTab('Dashboard')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all relative ${
                  activeTab === 'Dashboard'
                    ? 'bg-[#1b1c23] text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#16171d]'
                }`}
              >
                {/* Left Active indicator bar matching screenshot */}
                {activeTab === 'Dashboard' && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-white rounded-r"></span>
                )}
                <div className="flex items-center gap-3">
                  <LayoutDashboard size={16} className={activeTab === 'Dashboard' ? 'text-white' : 'text-slate-400'} />
                  {!isCollapsed && <span>Dashboard</span>}
                </div>
              </button>

              {/* Transactions */}
              <button
                onClick={() => setActiveTab('Transactions')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'Transactions'
                    ? 'bg-[#1b1c23] text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#16171d]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <ReceiptText size={16} className="text-slate-400" />
                  {!isCollapsed && <span>Transactions</span>}
                </div>
                {!isCollapsed && <ChevronRight size={13} className="text-slate-500" />}
              </button>

              {/* Sync */}
              <button
                onClick={() => setActiveTab('Sync')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'Sync'
                    ? 'bg-[#1b1c23] text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#16171d]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <RefreshCw size={16} className="text-slate-400" />
                  {!isCollapsed && <span>Sync</span>}
                </div>
                {!isCollapsed && <ChevronRight size={13} className="text-slate-500" />}
              </button>

              {/* Exceptions */}
              <button
                onClick={() => setActiveTab('Exceptions')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'Exceptions'
                    ? 'bg-[#1b1c23] text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#16171d]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <AlertCircle size={16} className="text-slate-400" />
                  {!isCollapsed && <span>Exceptions</span>}
                </div>
                {!isCollapsed && (
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                    <ChevronRight size={13} className="text-slate-500" />
                  </div>
                )}
              </button>

              {/* Reconciliations */}
              <button
                onClick={() => setActiveTab('Reconciliations')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'Reconciliations'
                    ? 'bg-[#1b1c23] text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#16171d]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <CheckCircle2 size={16} className="text-slate-400" />
                  {!isCollapsed && <span>Reconciliations</span>}
                </div>
                {!isCollapsed && <ChevronRight size={13} className="text-slate-500" />}
              </button>
            </nav>
          </div>

          {/* Settings Section */}
          <div>
            {!isCollapsed && (
              <div className="px-2 mb-2 text-[11px] font-medium text-slate-400 tracking-wide">
                Settings
              </div>
            )}
            <button
              onClick={() => setActiveTab('Settings')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'Settings'
                  ? 'bg-[#1b1c23] text-white'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#16171d]'
              }`}
            >
              <div className="flex items-center gap-3">
                <Settings size={16} className="text-slate-400" />
                {!isCollapsed && <span>Settings</span>}
              </div>
              {!isCollapsed && <ChevronRight size={13} className="text-slate-500" />}
            </button>
          </div>
        </div>
      </div>

      {/* AI Engine Status Pill at Bottom */}
      {!isCollapsed ? (
        <div className="p-3 border-t border-[#1f2128]">
          <div className="bg-[#171920] border border-[#232630] rounded-lg p-3 text-xs">
            <div className="flex items-center justify-between mb-1">
              <span className="text-white font-semibold flex items-center gap-1.5">
                <Shield size={14} className="text-blue-400" /> ScamShield AI
              </span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded-full font-mono">
                v2.4 LIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Continuous neural pattern evaluation on PayPal stream.
            </p>
          </div>
        </div>
      ) : (
        <div className="p-3 border-t border-[#1f2128] flex justify-center">
          <div className="w-3 h-3 rounded-full bg-emerald-400 shadow-glow-cyan" title="ScamShield AI Live"></div>
        </div>
      )}
    </aside>
  );
}
