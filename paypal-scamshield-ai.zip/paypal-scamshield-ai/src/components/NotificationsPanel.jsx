import React, { useState } from 'react';
import { 
  Bell, 
  Check, 
  Clock, 
  AlertCircle, 
  RefreshCw, 
  FileText, 
  AlertTriangle, 
  User,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { INITIAL_NOTIFICATIONS } from '../data/mockData';

export default function NotificationsPanel() {
  const [notifications, setNotifications] = useState(INITIAL_NOTIFICATIONS);
  const [isExpanded, setIsExpanded] = useState(false);

  const renderIcon = (item) => {
    switch (item.iconType) {
      case 'check':
        return (
          <div className="w-6 h-6 rounded-full bg-[#10b981] flex items-center justify-center shrink-0">
            <Check size={13} className="text-white stroke-[2.5]" />
          </div>
        );
      case 'clock':
        return (
          <div className="w-6 h-6 rounded-full bg-[#2a2d37] flex items-center justify-center shrink-0">
            <Clock size={12} className="text-slate-300" />
          </div>
        );
      case 'alert':
        return (
          <div className="w-6 h-6 rounded-full bg-[#2a2d37] flex items-center justify-center shrink-0">
            <AlertCircle size={12} className="text-slate-300" />
          </div>
        );
      case 'refresh':
        return (
          <div className="w-6 h-6 rounded-full bg-[#2a2d37] flex items-center justify-center shrink-0">
            <RefreshCw size={12} className="text-slate-300" />
          </div>
        );
      case 'file':
        return (
          <div className="w-6 h-6 rounded-full bg-[#2563eb] flex items-center justify-center shrink-0">
            <FileText size={12} className="text-white" />
          </div>
        );
      case 'danger':
        return (
          <div className="w-6 h-6 rounded-full bg-[#ef4444] flex items-center justify-center shrink-0">
            <AlertTriangle size={12} className="text-white" />
          </div>
        );
      case 'user':
        return (
          <div className="w-6 h-6 rounded-full bg-[#2a2d37] flex items-center justify-center shrink-0">
            <User size={12} className="text-slate-300" />
          </div>
        );
      default:
        return (
          <div className="w-6 h-6 rounded-full bg-[#2a2d37] flex items-center justify-center shrink-0">
            <Bell size={12} className="text-slate-300" />
          </div>
        );
    }
  };

  const displayedNotifications = isExpanded ? notifications : notifications.slice(0, 7);

  return (
    <div className="bg-[#18191e] border border-[#23252e] rounded-xl p-5 mb-6 shadow-sm">
      {/* Header matching screenshot */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-semibold text-white tracking-wide">
          Notifications
        </h2>
        <div className="w-6 h-6 rounded-full bg-[#1b1d24] border border-[#262833] flex items-center justify-center text-slate-400">
          <Bell size={12} />
        </div>
      </div>

      {/* Notifications List matching screenshot */}
      <div className="space-y-3.5">
        {displayedNotifications.map((notif) => (
          <div 
            key={notif.id}
            className="flex items-start gap-3 group cursor-pointer hover:bg-[#15161b]/60 p-1.5 -mx-1.5 rounded-lg transition-colors"
          >
            {renderIcon(notif)}

            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-medium text-slate-200 group-hover:text-blue-400 transition-colors truncate">
                {notif.title}
              </h4>
              <p className="text-[11px] text-slate-400 leading-snug line-clamp-1 mt-0.5">
                {notif.subtitle}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* SEE ALL toggle button matching screenshot */}
      <div className="mt-4 pt-3 border-t border-[#23252e] text-center">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-[11px] font-semibold text-slate-400 hover:text-white transition-colors tracking-wider uppercase inline-flex items-center gap-1.5"
        >
          <span>{isExpanded ? 'COLLAPSE' : 'SEE ALL'}</span>
          {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
        </button>
      </div>
    </div>
  );
}
