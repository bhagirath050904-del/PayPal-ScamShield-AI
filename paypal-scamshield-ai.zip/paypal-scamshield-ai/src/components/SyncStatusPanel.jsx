import React from 'react';
import { ChevronRight } from 'lucide-react';
import { SYNC_STATUS_ITEMS } from '../data/mockData';

export default function SyncStatusPanel({ onFilterByStatus }) {
  return (
    <div className="bg-[#18191e] border border-[#23252e] rounded-xl p-5 shadow-sm">
      {/* Header matching screenshot */}
      <div className="flex items-center gap-1.5 mb-4 cursor-pointer group">
        <h2 className="text-sm font-semibold text-white tracking-wide group-hover:text-blue-400 transition-colors">
          Sync Status
        </h2>
        <ChevronRight size={16} className="text-slate-400 group-hover:text-blue-400 transition-colors" />
      </div>

      {/* 4 Status Bars matching screenshot */}
      <div className="space-y-2.5">
        {SYNC_STATUS_ITEMS.map((item) => (
          <div
            key={item.id}
            onClick={() => onFilterByStatus && onFilterByStatus(item.id)}
            className="flex items-center justify-between px-4 py-3 rounded-lg border transition-all cursor-pointer hover:brightness-110 active:scale-[0.99]"
            style={{
              backgroundColor: item.barBg,
              borderColor: `${item.dotColor}33`
            }}
          >
            {/* Left dot + label */}
            <div className="flex items-center gap-2.5">
              <span
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: item.dotColor }}
              ></span>
              <span 
                className="text-xs font-medium font-sans"
                style={{ color: item.textColor }}
              >
                {item.label}
              </span>
            </div>

            {/* Right count */}
            <span 
              className="text-xs font-bold font-mono"
              style={{ color: item.textColor }}
            >
              {item.count}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
