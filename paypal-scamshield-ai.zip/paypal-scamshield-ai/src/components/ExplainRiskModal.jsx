import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  MapPin, 
  Globe, 
  Cpu, 
  Smartphone, 
  Clock, 
  CreditCard, 
  CheckCircle2, 
  Send,
  Ban,
  ArrowRight
} from 'lucide-react';

export default function ExplainRiskModal({ transaction, onClose, onActionTaken }) {
  if (!transaction) return null;

  const [actionDone, setActionDone] = useState(null);

  const handleAction = (actionType) => {
    setActionDone(actionType);
    if (onActionTaken) {
      setTimeout(() => {
        onActionTaken(transaction.id, actionType);
        onClose();
      }, 1200);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 70) return '#ef4444'; // Red
    if (score >= 40) return '#f59e0b'; // Amber
    return '#10b981'; // Green
  };

  const scoreColor = getScoreColor(transaction.riskScore);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-[#181920] border border-[#2d303f] w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[#242633] flex items-center justify-between bg-[#15161b]">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white"
              style={{ backgroundColor: `${scoreColor}22`, border: `1px solid ${scoreColor}44` }}
            >
              {transaction.riskLevel === 'High' && <AlertTriangle size={20} className="text-rose-500" />}
              {transaction.riskLevel === 'Medium' && <ShieldAlert size={20} className="text-amber-500" />}
              {transaction.riskLevel === 'Low' && <ShieldCheck size={20} className="text-emerald-500" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white font-mono">
                  {transaction.id}
                </h3>
                <span className="text-xs text-slate-400 font-sans">
                  • {transaction.customer}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                ScamShield AI Deep Risk Assessment & Explainability
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#1f212c] hover:bg-[#282a38] text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Top Score & Telemetry Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Risk Gauge Card */}
            <div className="bg-[#14151a] border border-[#242735] p-4 rounded-xl flex flex-col items-center justify-center text-center">
              <span className="text-[11px] font-medium text-slate-400 mb-1">Risk Score</span>
              <div className="relative w-20 h-20 flex items-center justify-center my-1">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-slate-800"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    strokeDasharray={`${transaction.riskScore}, 100`}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    stroke={scoreColor}
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className="text-xl font-bold font-mono text-white">
                    {transaction.riskScore}
                  </span>
                  <span className="text-[9px] uppercase tracking-wider font-semibold" style={{ color: scoreColor }}>
                    {transaction.riskLevel}
                  </span>
                </div>
              </div>
              <span className="text-[10px] text-slate-400">Scam confidence index</span>
            </div>

            {/* Payment Details Card */}
            <div className="bg-[#14151a] border border-[#242735] p-4 rounded-xl flex flex-col justify-between sm:col-span-2 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-500 text-[11px] block">Amount</span>
                  <span className="text-lg font-bold text-white font-mono">{transaction.total}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">Payment Method</span>
                  <span className="text-slate-200 font-medium">{transaction.paymentMethod}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">IP Address & Location</span>
                  <span className="text-slate-300 font-mono text-[11px] flex items-center gap-1">
                    <MapPin size={11} className="text-rose-400 shrink-0" />
                    {transaction.location}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">Timestamp</span>
                  <span className="text-slate-300 font-mono text-[11px] flex items-center gap-1">
                    <Clock size={11} className="text-slate-400 shrink-0" />
                    {transaction.date} • {transaction.timestamp || '12:00 UTC'}
                  </span>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-[#222430] flex items-center justify-between text-[11px] text-slate-400">
                <span>Payer Email:</span>
                <span className="text-blue-400 font-mono">{transaction.email}</span>
              </div>
            </div>
          </div>

          {/* Section 1: Explain Why a Payment Looks Suspicious */}
          <div>
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <ShieldAlert size={14} className="text-amber-400" />
              Why this payment looks suspicious (AI Explanation)
            </h4>
            <div className="space-y-2">
              {transaction.reasons.map((reason, idx) => (
                <div 
                  key={idx}
                  className="bg-[#14151a] border border-[#242735] p-3 rounded-lg text-xs text-slate-300 flex items-start gap-2.5"
                >
                  <span className="w-5 h-5 rounded-md bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center shrink-0 text-[10px] font-mono mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="leading-relaxed">{reason}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Section 2: Identified Unusual Payment Patterns */}
          <div>
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <Cpu size={14} className="text-blue-400" />
              Identified Unusual Payment Patterns
            </h4>
            <div className="flex flex-wrap gap-2">
              {transaction.patterns.map((pat, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1.5 rounded-lg bg-blue-950/40 border border-blue-500/30 text-blue-300 text-xs font-medium flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
                  {pat}
                </span>
              ))}
            </div>
          </div>

          {/* Section 3: Autonomous AI Recommendation */}
          <div className="bg-gradient-to-r from-[#171c2b] to-[#161f2e] border border-blue-500/30 p-4 rounded-xl relative overflow-hidden">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-glow-blue">
                <CheckCircle2 size={18} />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
                    AI Decision & Recommendation
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                    transaction.suggestedAction === 'BLOCK_IMMEDIATELY'
                      ? 'bg-rose-500 text-white'
                      : transaction.suggestedAction === 'REQUEST_VERIFICATION'
                      ? 'bg-amber-500 text-black'
                      : 'bg-emerald-500 text-white'
                  }`}>
                    {transaction.suggestedAction}
                  </span>
                </div>
                <p className="text-xs text-slate-200 font-medium leading-relaxed">
                  {transaction.recommendation}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="px-6 py-4 border-t border-[#242633] bg-[#14151b] flex flex-wrap items-center justify-between gap-3">
          {actionDone ? (
            <div className="w-full text-center py-2 text-xs font-semibold text-emerald-400 flex items-center justify-center gap-2">
              <CheckCircle2 size={16} />
              Action executed: {actionDone.replace('_', ' ')}! Updating risk ledger...
            </div>
          ) : (
            <>
              <div className="text-[11px] text-slate-400">
                Action will update live PayPal dispute prevention ledger.
              </div>

              <div className="flex items-center gap-2.5">
                {/* Secondary: Block */}
                <button
                  onClick={() => handleAction('BLOCK_AND_REPORT')}
                  className="px-3.5 py-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-medium transition-colors flex items-center gap-1.5"
                >
                  <Ban size={14} />
                  Block & Report
                </button>

                {/* Recommend Action 1: Request Verification */}
                <button
                  onClick={() => handleAction('REQUEST_VERIFICATION')}
                  className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
                >
                  <Send size={14} />
                  Request Verification (SMS/2FA)
                </button>

                {/* Proceed button */}
                <button
                  onClick={() => handleAction('PROCEED_APPROVE')}
                  className="px-4 py-2 rounded-lg bg-[#2563eb] hover:bg-blue-600 text-white text-xs font-semibold shadow-glow-blue transition-all flex items-center gap-1.5"
                >
                  <ShieldCheck size={14} />
                  Proceed Safely
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
