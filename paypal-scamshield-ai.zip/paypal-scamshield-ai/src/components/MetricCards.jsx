import React from 'react';
import { ArrowUpRight, TrendingUp, Info } from 'lucide-react';

export default function MetricCards({ metrics }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {metrics.map((metric) => (
        <div
          key={metric.id}
          className="bg-[#18191e] hover:bg-[#1b1c23] border border-[#23252e] hover:border-[#2d303b] transition-all duration-200 rounded-xl p-4 sm:p-5 flex flex-col justify-between group relative overflow-hidden shadow-sm"
        >
          {/* Card Top: Title on left, Value & Arrow on right */}
          <div className="flex items-start justify-between gap-2 mb-4">
            <div>
              <h3 className="text-xs font-semibold text-slate-300 tracking-wide font-sans">
                {metric.title}
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5 font-normal">
                {metric.subtitle}
              </p>
            </div>
            
            <div className="flex items-baseline gap-1 text-right">
              <span className="text-lg sm:text-xl font-bold text-white tracking-tight font-sans">
                {metric.value}
              </span>
              <span 
                className="text-xs font-semibold"
                style={{ color: metric.barColor }}
              >
                {metric.change}
              </span>
            </div>
          </div>

          {/* Bottom Progress Bar matching screenshot */}
          <div className="w-full">
            <div className="w-full h-1 bg-[#23252f] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-1000 ease-out"
                style={{
                  width: `${metric.progress}%`,
                  backgroundColor: metric.barColor,
                  boxShadow: `0 0 10px ${metric.barColor}66`
                }}
              ></div>
            </div>

            {/* Subtle AI tooltip on hover */}
            <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 opacity-90 group-hover:opacity-100 transition-opacity">
              <span>{metric.badgeText}</span>
              <span className="text-slate-400 group-hover:text-slate-200 flex items-center gap-1 font-mono">
                AI verified
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
