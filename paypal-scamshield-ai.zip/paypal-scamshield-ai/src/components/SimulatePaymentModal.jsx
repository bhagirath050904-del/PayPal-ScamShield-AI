import React, { useState } from 'react';
import { 
  X, 
  Zap, 
  Sparkles, 
  AlertTriangle, 
  ShieldCheck, 
  ShieldAlert, 
  Globe, 
  CreditCard, 
  Cpu, 
  ArrowRight,
  RotateCcw
} from 'lucide-react';

const PRESETS = [
  {
    name: 'Suspicious Cross-Border Spike',
    amount: 1850.00,
    email: 'new_buyer_881@tempmail.ninja',
    location: 'Lagos, Nigeria (Billing: Chicago, IL)',
    ip: '102.89.44.12',
    method: 'PayPal Balance Transfer',
    device: 'Emulated Android (BlueStacks)',
    velocity: '6 requests in 45s'
  },
  {
    name: 'Bot Card-Testing Micro-Charge',
    amount: 3.50,
    email: 'alpha_probe@fastmail.com',
    location: 'Frankfurt, DE (Tor Exit Node)',
    ip: '185.220.101.4',
    method: 'Stripe Guest Checkout',
    device: 'Python-Requests / Headless',
    velocity: '18 requests in 2 mins'
  },
  {
    name: 'Legitimate Verified Recurring User',
    amount: 49.00,
    email: 'emily.turner@designstudio.co',
    location: 'Seattle, WA, United States',
    ip: '73.181.20.91',
    method: 'PayPal Confirmed Visa (..3910)',
    device: 'Safari macOS Sonoma (Apple Silicon)',
    velocity: '1 request / monthly'
  }
];

export default function SimulatePaymentModal({ isOpen, onClose, onAddTransaction }) {
  if (!isOpen) return null;

  const [formData, setFormData] = useState({
    amount: '1250.00',
    customer: 'Victor Sterling',
    email: 'v.sterling.99@temp-inbox.net',
    location: 'Saint Petersburg, RU (Billing: Dallas, TX)',
    ip: '185.190.140.22',
    method: 'PayPal Balance',
    device: 'Headless Chrome / Puppeteer'
  });

  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState(null);

  const applyPreset = (preset) => {
    setFormData({
      amount: preset.amount.toFixed(2),
      customer: preset.name.split(' ')[0] + ' ' + (preset.name.split(' ')[1] || 'User'),
      email: preset.email,
      location: preset.location,
      ip: preset.ip,
      method: preset.method,
      device: preset.device
    });
    setResult(null);
  };

  const handleRunScan = () => {
    setIsScanning(true);
    setResult(null);

    setTimeout(() => {
      const amountNum = parseFloat(formData.amount) || 50;
      const isTorOrTemp = formData.email.includes('temp') || formData.location.includes('Tor') || formData.location.includes('Lagos') || formData.location.includes('RU');
      const isHighAmount = amountNum > 1000;
      
      let riskScore = 15;
      let riskLevel = 'Low';
      let suggestedAction = 'PROCEED';
      let aiVerdict = 'Proceed Safely';
      let reasons = [];
      let patterns = [];
      let recommendation = '';

      if (isTorOrTemp && isHighAmount) {
        riskScore = 96;
        riskLevel = 'High';
        suggestedAction = 'BLOCK_IMMEDIATELY';
        aiVerdict = 'Block & Report Fraud';
        reasons = [
          'Critical Geo-IP Anomaly: IP connection location is over 6,000 miles away from registered PayPal account billing address.',
          'Disposable Email Domain: Email domain is recognized as temporary throwaway mail often utilized in chargeback fraud.',
          'High Transaction Magnitude: Payment is significantly above merchant historical baseline for unverified devices.'
        ];
        patterns = [
          'High-risk overseas proxy / VPN tunnel',
          'Automated checkout script telemetry detected'
        ];
        recommendation = 'Autonomous Decline Recommended. Do not accept authorization. Block origin IP address and flag PayPal account for audit.';
      } else if (isTorOrTemp || isHighAmount) {
        riskScore = 67;
        riskLevel = 'Medium';
        suggestedAction = 'REQUEST_VERIFICATION';
        aiVerdict = 'Request Verification';
        reasons = [
          'Location Discrepancy: Geolocation lookup indicates cross-border session without prior historical travel pattern.',
          'Unrecognized Device Fingerprint: First time transaction on this browser / device combination.'
        ];
        patterns = [
          'Possible credential sharing or unexpected session takeover',
          'Elevated basket risk score'
        ];
        recommendation = 'Request Step-Up Verification (Biometric SMS / 2FA OTP) before releasing order fulfillment or balance payout.';
      } else {
        riskScore = 12;
        riskLevel = 'Low';
        suggestedAction = 'PROCEED';
        aiVerdict = 'Proceed Safely';
        reasons = [
          'Matching Geolocation: Device IP, billing zip code, and confirmed shipping address fully align.',
          'Established Payment Method: Clean dispute history with zero chargeback filings.',
          'Natural human mouse velocity and biometric telemetry.'
        ];
        patterns = [
          'Standard low-risk consumer checkout'
        ];
        recommendation = 'Proceed immediately. Safe for 1-click clearance.';
      }

      const evalResult = {
        id: '#' + Math.floor(100000 + Math.random() * 900000),
        customer: formData.customer,
        email: formData.email,
        date: 'Today',
        timestamp: 'Just now',
        status: 'Completed',
        statusColor: 'emerald',
        total: `$${parseFloat(formData.amount).toFixed(2)}`,
        amountNum: parseFloat(formData.amount),
        currency: 'USD',
        paymentMethod: formData.method,
        ipAddress: formData.ip,
        location: formData.location,
        riskLevel,
        riskScore,
        aiVerdict,
        reasons,
        patterns,
        recommendation,
        suggestedAction
      };

      setResult(evalResult);
      setIsScanning(false);
    }, 900);
  };

  const handleCommitToTable = () => {
    if (result && onAddTransaction) {
      onAddTransaction(result);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-[#181920] border border-[#2d303f] w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#242633] flex items-center justify-between bg-[#15161b]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-glow-blue">
              <Zap size={16} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                PayPal ScamShield AI • Live Fraud Simulator
              </h3>
              <p className="text-xs text-slate-400">
                Test real-time neural fraud pattern scoring & decision recommendations
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#1f212c] hover:bg-[#282a38] text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Preset Buttons */}
          <div>
            <label className="text-xs font-semibold text-slate-400 mb-2 block uppercase tracking-wider">
              Load Realistic Fraud Scenarios:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {PRESETS.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => applyPreset(p)}
                  className="px-3 py-2 text-left rounded-lg bg-[#14151a] hover:bg-[#1f212c] border border-[#242735] hover:border-blue-500/40 text-xs text-slate-300 hover:text-white transition-all flex flex-col justify-between"
                >
                  <span className="font-semibold text-slate-200 text-[11px] mb-1">{p.name}</span>
                  <span className="text-[10px] text-blue-400 font-mono">${p.amount.toFixed(2)}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Input Form */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-slate-400 font-medium mb-1 block">Customer Name</label>
              <input
                type="text"
                value={formData.customer}
                onChange={(e) => setFormData({ ...formData, customer: e.target.value })}
                className="w-full bg-[#131418] border border-[#272935] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="text-slate-400 font-medium mb-1 block">Payer Email</label>
              <input
                type="text"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full bg-[#131418] border border-[#272935] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="text-slate-400 font-medium mb-1 block">Amount ($ USD)</label>
              <input
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full bg-[#131418] border border-[#272935] rounded-lg px-3 py-2 text-white text-xs font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="text-slate-400 font-medium mb-1 block">Payment Method</label>
              <input
                type="text"
                value={formData.method}
                onChange={(e) => setFormData({ ...formData, method: e.target.value })}
                className="w-full bg-[#131418] border border-[#272935] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-slate-400 font-medium mb-1 block">Geo-Location & IP Context</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full bg-[#131418] border border-[#272935] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Trigger Scan Button */}
          <button
            onClick={handleRunScan}
            disabled={isScanning}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs transition-all shadow-glow-blue flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isScanning ? (
              <>
                <Sparkles size={14} className="animate-spin text-sky-200" />
                <span>ScamShield AI Neural Analysis in Progress...</span>
              </>
            ) : (
              <>
                <Zap size={14} />
                <span>Run ScamShield AI Fraud Scan</span>
              </>
            )}
          </button>

          {/* Scan Results Output */}
          {result && (
            <div className="bg-[#14151a] border border-[#282b3a] rounded-xl p-4 space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between border-b border-[#222430] pb-3">
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded text-xs font-bold font-mono ${
                    result.riskLevel === 'High' ? 'bg-rose-500 text-white' :
                    result.riskLevel === 'Medium' ? 'bg-amber-500 text-black' : 'bg-emerald-500 text-white'
                  }`}>
                    {result.riskLevel} Risk • {result.riskScore}%
                  </span>
                  <span className="text-xs text-slate-300 font-semibold">{result.aiVerdict}</span>
                </div>
                <span className="text-xs text-slate-400 font-mono">{result.id}</span>
              </div>

              {/* Reasons */}
              <div>
                <span className="text-[11px] font-semibold text-slate-400 block mb-1">
                  AI Rationale:
                </span>
                <ul className="space-y-1">
                  {result.reasons.map((r, i) => (
                    <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                      <span className="text-blue-400 mt-0.5">•</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Recommendation */}
              <div className="bg-[#1a1c26] p-2.5 rounded-lg border border-blue-500/20 text-xs text-slate-200">
                <strong className="text-blue-400">Recommendation: </strong>
                {result.recommendation}
              </div>

              {/* Commit button */}
              <button
                onClick={handleCommitToTable}
                className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-all flex items-center justify-center gap-1.5"
              >
                <ShieldCheck size={14} />
                <span>Add this transaction to Live Dashboard Table</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
