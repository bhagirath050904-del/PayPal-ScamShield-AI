import React from 'react';
import { 
  ShieldCheck, 
  Cpu, 
  Activity, 
  HelpCircle, 
  CheckCircle, 
  ArrowRight, 
  Sparkles, 
  Lock, 
  Zap, 
  ChevronRight,
  SlidersHorizontal,
  BellRing,
  Globe2,
  DollarSign
} from 'lucide-react';

export default function LandingPageView({ onGoToDashboard, onOpenSimulator }) {
  const features = [
    {
      icon: Activity,
      title: "1. Detect Suspicious Transactions",
      desc: "Real-time stream inspection on every PayPal & Stripe checkout. Flags synthetic identities, burner emails, and stolen cards within 18 milliseconds.",
      tag: "18ms Latency",
      color: "from-blue-600 to-cyan-500"
    },
    {
      icon: Cpu,
      title: "2. Identify Unusual Payment Patterns",
      desc: "Detects micro-charge smurfing probes, velocity spikes from single IP clusters, impossible travel geolocations, and headless browser bots.",
      tag: "Pattern Intelligence",
      color: "from-purple-600 to-pink-500"
    },
    {
      icon: Lock,
      title: "3. Tri-Tier Risk Scoring (Low, Medium, High)",
      desc: "Every transaction receives an explainable 0–100 confidence score grouped into Low (green), Medium (amber), and High (red) risk classifications.",
      tag: "Tri-Tier Scoring",
      color: "from-amber-500 to-orange-500"
    },
    {
      icon: HelpCircle,
      title: "4. Explain Why a Payment Looks Suspicious",
      desc: "No black-box decisions. Instant natural language rationale citing exact geo-mismatches, behavioral keystrokes, and Tor exit relays.",
      tag: "Explainable AI",
      color: "from-sky-500 to-blue-600"
    },
    {
      icon: CheckCircle,
      title: "5. Autonomous Action Recommendations",
      desc: "Provides clear, decisive guidance on every transaction: proceed with instant settlement, or request step-up biometric/SMS verification before release.",
      tag: "Zero Guesswork",
      color: "from-emerald-500 to-teal-500"
    }
  ];

  return (
    <div className="min-h-screen bg-[#121316] text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 px-6 max-w-7xl mx-auto text-center">
        {/* Glowing backdrop elements */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-blue-600/15 rounded-full blur-[140px] pointer-events-none"></div>

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/25 text-blue-400 text-xs font-semibold mb-6">
          <Sparkles size={14} className="text-sky-300 animate-spin" />
          <span>Next-Generation PayPal & Stripe Payment Security</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight max-w-4xl mx-auto leading-tight">
          PayPal <span className="bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-400 bg-clip-text text-transparent">ScamShield AI</span>
        </h1>
        <p className="mt-4 text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto font-normal">
          AI-powered payment fraud detection designed for modern high-volume merchants. Stop chargebacks, block bot attacks, and protect honest customers.
        </p>

        {/* CTA Buttons */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={onGoToDashboard}
            className="px-6 py-3 rounded-xl bg-[#2563eb] hover:bg-blue-600 text-white font-semibold text-sm shadow-glow-blue transition-all flex items-center gap-2 active:scale-95"
          >
            <span>Launch Live Security Dashboard</span>
            <ArrowRight size={16} />
          </button>

          <button
            onClick={onOpenSimulator}
            className="px-6 py-3 rounded-xl bg-[#1b1c23] hover:bg-[#232530] text-slate-200 border border-[#2c2f3d] font-semibold text-sm transition-all flex items-center gap-2"
          >
            <Zap size={16} className="text-emerald-400" />
            <span>Try Fraud AI Simulator</span>
          </button>
        </div>

        {/* Metric Highlights */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {[
            { val: "99.8%", lbl: "Precision Rate", sub: "Dispute avoidance" },
            { val: "18ms", lbl: "Latency", sub: "Real-time decision" },
            { val: "$324K+", lbl: "Protected Monthly", sub: "Zero false-positive lock" },
            { val: "100%", lbl: "Explainable", sub: "Clear human reasoning" }
          ].map((m, i) => (
            <div key={i} className="p-4 rounded-xl bg-[#18191e]/80 border border-[#23252e] backdrop-blur">
              <div className="text-2xl font-bold font-mono text-white">{m.val}</div>
              <div className="text-xs font-semibold text-slate-300 mt-1">{m.lbl}</div>
              <div className="text-[11px] text-slate-500">{m.sub}</div>
            </div>
          ))}
        </div>
      </section>

      {/* 5 Core Pillars Section (Directly from User Prompt) */}
      <section className="py-16 px-6 max-w-7xl mx-auto border-t border-[#1f2129]">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-xs font-bold uppercase tracking-widest text-blue-400 mb-2">
            Engine Capabilities
          </h2>
          <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            5 Ways ScamShield AI Defends Your Revenues
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <div 
                key={i} 
                className="bg-[#18191e] border border-[#23252e] hover:border-[#2f3342] rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 group relative flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${f.color} flex items-center justify-center text-white shadow-md`}>
                      <Icon size={20} />
                    </div>
                    <span className="text-[10px] px-2.5 py-1 rounded-full bg-[#131418] border border-[#262835] text-slate-400 font-mono">
                      {f.tag}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">
                    {f.title}
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed font-normal">
                    {f.desc}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-[#23252f] flex items-center text-xs font-medium text-blue-400 group-hover:text-blue-300 cursor-pointer">
                  <span onClick={onGoToDashboard}>See in Live Dashboard</span>
                  <ChevronRight size={14} className="ml-1 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}

          {/* Interactive Card */}
          <div className="bg-gradient-to-br from-[#1b1f2e] to-[#14151c] border border-blue-500/30 rounded-2xl p-6 flex flex-col justify-between text-left relative overflow-hidden">
            <div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
                Interactive Playground
              </span>
              <h4 className="text-base font-bold text-white mt-3 mb-2">
                Simulate Any Suspicious Transaction
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Test custom IP addresses, amounts, Tor exit nodes, and synthetic patterns to observe instant AI scoring and explainable rationale.
              </p>
            </div>

            <button
              onClick={onOpenSimulator}
              className="mt-6 w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-glow-blue flex items-center justify-center gap-2 transition-all"
            >
              <Zap size={14} />
              <span>Launch Simulator</span>
            </button>
          </div>
        </div>
      </section>

      {/* Embedded Dashboard Preview Banner */}
      <section className="py-12 px-6 max-w-7xl mx-auto text-center border-t border-[#1f2129]">
        <h3 className="text-xl font-bold text-white mb-2">
          Designed Exactly Like Your High-Velocity Operations Room
        </h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto mb-6">
          Toggle back to the live operations dashboard at any time to inspect every real-time metric, graph, and transaction.
        </p>
        <button
          onClick={onGoToDashboard}
          className="px-5 py-2.5 rounded-xl bg-[#2563eb] text-white font-semibold text-xs hover:bg-blue-600 transition-all shadow-glow-blue inline-flex items-center gap-2"
        >
          <span>Open Full Operational Dashboard</span>
          <ArrowRight size={14} />
        </button>
      </section>
    </div>
  );
}
